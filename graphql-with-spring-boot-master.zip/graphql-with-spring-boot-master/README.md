# graphql-with-spring-boot
A sample application with GraphQL and Spring Boot
